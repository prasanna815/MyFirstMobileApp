from kivy.app import App
from kivy.lang import Builder
from kivy.uix.boxlayout import BoxLayout
from kivy.garden.navigationdrawer import NavigationDrawer
from kivy.uix.image import Image,AsyncImage
from kivy.uix.button import Button
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
class Menu(Screen):
    pass
class normal(Screen):
    pass
class oil(Screen):
    pass
class MyScreenManager(ScreenManager):
    pass
root_widget=Builder.load_string('''
#<KvLang>
MyScreenManager:
    Menu:
    normal:
    oil:
<Menu>:
    name: 'navigation'
    NavigationDrawer:
        id:nav
        BoxLayout:
            orientation:"vertical"
            
            Label:
                text: 'Contact Me:\\nM.Prasanna\\nanbilprasanna7@gmail.com\\n+91-8124106390\\nInstagram : prasanna_umadevi\\nfacebook : prasanna anbil'
        BoxLayout:
            orientation:"vertical"
            ActionBar:
                background_color:0,191,255,0.5
                ActionView:
                    ActionPrevious:
                        icon_app:"mylogo.png"
                        title:"Prasanna Creations"
                        on_release:nav.toggle_state()
            Image:
                source:'mylogo.png'
                size_hint:1,0.5
            Image:
                source:'check.png'
                size_hint:1,0.3
            
            
                    
            Button:
                text:"NORMAL EDIT"
                size_hint:1,0.1
                background_color:0,191,255,0.5
                on_release:app.root.current='nor'
            Button:
                text:"OIL PAINT EDIT"
                size_hint:1,0.1
                background_color:0,191,255,0.5
                on_release:app.root.current='oilp'
<normal>:
    name: 'nor'
    BoxLayout:
        orientation: 'vertical'
        Image:
            source: 'ne.jpg'
        Button:
            text:"Back"
            background_color:0,191,255,0.5
            size_hint:1,0.1
            on_release:app.root.current='navigation'
<oil>:
    name: 'oilp'
    BoxLayout:
        orientation: 'vertical'
        Image:
            source: 'OILP.png'
        Button:
            text:"Back"
            background_color:0,191,255,0.5
            size_hint:1,0.1
            on_release:app.root.current='navigation'
#</KvLang>
''')
class MyApp(App):
    def build(self):
        return root_widget
        
if __name__=="__main__":
    MyApp().run()
